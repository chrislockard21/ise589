# -*- coding: utf-8 -*-
"""
@author: bstarly

"""

import zipfile as zp
import csv

#extract the 5000-sales-records.zip file





# count the number of units sold

    



# which country had the highest sales revenue





# Print out the max order sold by each country in the file and store the result in a dictionary






#Output a file that lists each Item_Type and the countries that sold those items


