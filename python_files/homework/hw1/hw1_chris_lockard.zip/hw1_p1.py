'''

@author: Chris Lockard

Problem 1:
Write a program that assigns and prints two intigers and one float to variables.

'''

# Define variables
x = 10
y = 15
z = 12.6

# Prints types and value of variables
print(type(x), x)
print(type(y), y)
print(type(z), z)
