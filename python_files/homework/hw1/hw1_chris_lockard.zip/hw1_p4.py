'''

@author: Chris Lockard

Problem 4:
Write a program that prints a big P (as seen in the hw assignment).

'''

print(
'''
* * * * *
*         *
*        *
*       *
*  *  *
*
*
*
*
'''
)
