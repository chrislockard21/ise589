'''

@author: Chris Lockard

Problem 8:
Write a program that reverses the letters in the user input name.

'''

# Accepts the users full name
full_name = input('Please provide your full name: ')

# Prints the reversed name
print('Input: ' + full_name + '\nOutput: ' + full_name[::-1])
